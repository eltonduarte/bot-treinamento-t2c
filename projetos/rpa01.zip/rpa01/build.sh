#!/bin/bash

zip -r "rpa01.zip" * -x "rpa01.zip"